﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace cinema
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        string connectionString;
        SqlCommand choosecinema;
        SqlDataReader Cinemas;

        public Window2()
        {
            InitializeComponent();

            connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
            SqlConnection con = new SqlConnection(connectionString);
            choosecinema = new SqlCommand();
            con.Open();
            choosecinema.Connection = con;
            choosecinema.CommandText = "Select * from Cinemas";
            Cinemas = choosecinema.ExecuteReader();
            while (Cinemas.Read())
            {
                ChooseCinema.Items.Add(Cinemas["Name_cinema"]);
                
            }
            Cinemas.Close();
            
            con.Close();
            
        }
        
        private void ListboxCinemas_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
        }

        private void ListboxCinemas_Selected(object sender, RoutedEventArgs e)
        {

        }

        private void ExitButton_Click(object sender, RoutedEventArgs e)
        {
            Window1 window1 = new Window1();
            window1.Show();
            this.Close();
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ChooseFilm_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Frame_Navigated(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {

        }
    }
}
