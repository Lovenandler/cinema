﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace cinema
{


    public partial class authorization : Window
    {
        public authorization()
        {
            InitializeComponent();
        }
        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {


        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (LoginAuth.Text.Length > 0)
            {
                string[] dataLogin = LoginAuth.Text.Split('@');
                if (dataLogin.Length == 2)
                {
                    string[] data2Login = dataLogin[1].Split('.');
                    if (data2Login.Length == 2)
                    {

                        if (PasswordAuth.Text.Length >= 6)
                        {

                            bool en = true;
                            bool symbol = false;
                            bool number = false;
                            bool letter = false;

                            for (int i = 0; i < PasswordAuth.Text.Length; i++) 
                            {
                                if (PasswordAuth.Text[i] >= 'А' && PasswordAuth.Text[i] <= 'Я' || PasswordAuth.Text[i] >= 'а' && PasswordAuth.Text[i] <= 'я') en = false;
                                if (PasswordAuth.Text[i] >= '0' && PasswordAuth.Text[i] <= '9') number = true;
                                if (PasswordAuth.Text[i] >= 'A' && PasswordAuth.Text[i] <= 'Z' || PasswordAuth.Text[i] >= 'a' && PasswordAuth.Text[i] <= 'z') letter = true;
                                if (PasswordAuth.Text[i] == '$' || PasswordAuth.Text[i] == '#' || PasswordAuth.Text[i] == '!') symbol = true;
                            }

                            if (!en)
                                MessageBox.Show("Доступна только английская раскладка");
                            else if (!symbol)
                                MessageBox.Show("Добавьте один из следующих символов: $ # !");
                            else if (!number)
                                MessageBox.Show("Добавьте хотя бы одну цифру");
                            else if (!letter)
                                MessageBox.Show("Добавьте хотя бы одну букву");
                            if (en && symbol && number && letter)
                            {
                                SqlConnection con = new SqlConnection(@"Data Source=LOVENANDLER\SQLEXPRESS;Initial Catalog=Cinema;Integrated Security=True");
                                string sql = string.Format("Insert Into Users" +
                   "(Email,Password) Values(@Email, @Password)");
                                SqlCommand check = new SqlCommand("Select count(*) from Users where Email = @Email", con);
                                check.Parameters.AddWithValue("@Email", this.LoginAuth.Text);
                                con.Open();
                                var result = check.ExecuteScalar();
                                if (result != null)
                                {
                                    MessageBox.Show("Пользователь уже зарегистрирован");
                                }
                                else
                                {


                                    using (SqlCommand cmd = new SqlCommand(sql, con))
                                    {

                                        cmd.Parameters.AddWithValue("@Email", LoginAuth.Text);
                                        cmd.Parameters.AddWithValue("@Password", PasswordAuth.Text);

                                        cmd.ExecuteNonQuery();
                                        con.Close();
                                    }

                                    /*string InsertQuery = "Insert into Users (Email,Password) Values ('" + LoginAuth.Text + "','" + PasswordAuth.Text + "')";
                                    con.Open();
                                    SqlCommand insertUser = new SqlCommand(InsertQuery, con);
                                    insertUser.ExecuteNonQuery();
                                    con.Close();*/
                                    if (pressed.IsChecked == true)
                                    {
                                        Window2 window2 = new Window2();
                                        window2.Show();

                                    }
                                    else
                                    {
                                        Window1 window1 = new Window1();
                                        window1.Show();

                                    }
                                    this.Close();
                                }
                            }
                        }
                            else MessageBox.Show("пароль слишком короткий, минимум 6 символов");
                    }
                        else MessageBox.Show("Укажите логин в форме название@почта.com");
                }
                    else MessageBox.Show("Укажите логин в форме название@почта.com");
            }
                else MessageBox.Show("Укажите логин");

        }

            private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
            {

            }

            private void Button_Click_1(object sender, RoutedEventArgs e)
            {

                Window1 window1 = new Window1();
                window1.Show();
                this.Close();
            }
    }
}

