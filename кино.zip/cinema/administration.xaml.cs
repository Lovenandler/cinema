﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace cinema
{
    /// <summary>
    /// Логика взаимодействия для administration.xaml
    /// </summary>
    public partial class administration : Window
    {
        public administration()
        {
            InitializeComponent();
        }

        private void NewFilmYear_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {

            /*int s = Convert.ToInt32(e.NewValue);
            string ss = String.Format("Current year: {0}", s);
            this.YearChange.Text = ss;
            */
            var s = sender as Slider;
            int value = (Int32)s.Value;
            if(YearChange != null)
            {
                this.YearChange.Text = value.ToString();
            }
            //this.Title = "Value: " + value.ToString();
            
        }

        private void YearChange_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
